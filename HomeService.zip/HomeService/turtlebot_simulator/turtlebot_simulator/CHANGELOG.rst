^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_simulator
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.3 (2017-09-18)
------------------

2.2.2 (2015-09-16)
------------------

2.2.1 (2015-08-07)
------------------

2.2.0 (2014-12-30)
------------------
* add turtlebot_stdr in meta package fixes `#44 <https://github.com/turtlebot/turtlebot_simulator/issues/44>`_
* add turtlebot_stage
* Contributors: Jihoon Lee

2.1.1 (2013-10-14)
------------------

2.1.0 (2013-08-30)
------------------
* Add bugtracker and repo info URLs.

2.0.0 (2013-07-16)
------------------

* Migrated to use stand-alone Gazebo installation
* All packages have been catkinized
