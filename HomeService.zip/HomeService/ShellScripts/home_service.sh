#!/bin/sh
CATKIN_DIR="$( cd $( dirname $BASH_SOURCE[0] )/../.. >/dev/null && pwd )"
echo "Launching Gazebo world..."
xterm  -e  "roslaunch turtlebot_gazebo turtlebot_world.launch world_file:=$CATKIN_DIR/src/worlds/HStest.world" &
sleep 5
echo "Launching AMCL..."
xterm -e "roslaunch turtlebot_gazebo amcl_demo.launch map_file:=$CATKIN_DIR/src/worlds/my_map.yaml" &
sleep 5
echo "Launching rviz..."
xterm -e "rosrun rviz rviz -d $CATKIN_DIR/src/RvizConfig/home_service.rviz" &
sleep 5
echo "Launching add markers..."
xterm -e "rosrun add_markers add_markers" &
sleep 5
echo "Launching pick objects..."
xterm -e "rosrun pick_objects pick_objects"
